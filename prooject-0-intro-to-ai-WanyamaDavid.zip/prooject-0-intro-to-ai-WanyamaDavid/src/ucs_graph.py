"""
Project 0, Task 3: Uniform Cost Search - Weighted Graph Search

Student Name: wanyama David - 2022/BSE/016/PS
Date: [15/10/2025]

Implement UCS to find optimal (lowest cost) paths in weighted graphs.
UCS expands nodes in order of path cost, guaranteeing optimal solutions.

Key Concepts:
- Uses priority queue ordered by path cost
- Explores lowest-cost paths first
- Complete and optimal for positive step costs
- Essential when actions have different costs
- Time/Space: O(b^(C*/ε)) where C*=optimal cost, ε=min step cost
"""

import heapq

class WeightedGraphUCS:
    def __init__(self, graph):
        """
        Initialize weighted graph search
        
        Args:
            graph: dict mapping node -> [(neighbor, cost), ...]
                  Example: {'A': [('B', 2), ('C', 3)], 'B': [('D', 1)], ...}
        """
        self.graph = graph
        
        # Statistics tracking
        self.nodes_explored = 0
        self.max_frontier_size = 0
        
    def get_neighbors(self, node):
        """
        Get neighbors and costs for a node
        
        Args:
            node: node identifier
            
        Returns:
            list: [(neighbor, cost), ...] or empty list if node not in graph
        """
        return self.graph.get(node, [])
    
    def uniform_cost_search(self, start, goal):
        """
        Implement UCS algorithm to find optimal cost path
        
        Args:
            start: starting node identifier
            goal: goal node identifier
            
        Returns:
            tuple: (path, total_cost, nodes_explored, max_frontier_size)
                path: list of nodes from start to goal, or None if no path
                total_cost: cost of optimal path, or None if no path
                nodes_explored: total number of nodes expanded
                max_frontier_size: maximum size of frontier during search
                
        TODO: Implement UCS algorithm!
        
        UCS Algorithm:
        1. Initialize priority queue with (cost, start, path)
        2. Initialize visited set (or best_cost dict for handling multiple paths)
        3. While priority queue not empty:
           a. Pop lowest cost (cost, node, path)
           b. If node is goal, return path and cost
           c. If node already visited with lower cost, skip
           d. Mark node as visited with current cost
           e. For each neighbor:
              - Calculate new cost = current_cost + edge_cost
              - If neighbor not visited or new cost is better, add to queue
        4. Return None if no path found
        
        Key UCS insight: Only expand a node when you reach it via optimal path!
        """
        # Reset statistics
        self.nodes_explored = 0
        self.max_frontier_size = 0
        
        # Check if start and goal are in graph
        if start not in self.graph or goal not in self.graph:
            return None, None, self.nodes_explored, self.max_frontier_size
        
        # Initialize UCS data structures
        # Priority queue: (cost, node, path)
        priority_queue = [(0, start, [start])]
        visited = {}  # node -> best_cost_so_far
        
        # TODO: Implement UCS main loop
        # Hint: Use heapq.heappop() to get lowest cost node
        # Hint: Update statistics (nodes_explored, max_frontier_size)
        # Hint: Skip nodes reached with better cost already
        # Hint: Only expand when reached via optimal path
        
        while priority_queue:
            # Track frontier size
            self.max_frontier_size = max(self.max_frontier_size, len(priority_queue))
            
            # Pop node with lowest path cost
            current_cost, node, path = heapq.heappop(priority_queue)
            
            # Skip if we've already found a cheaper path to this node
            if node in visited and current_cost > visited[node]:
                continue
            
            # Record the cost for this node
            visited[node] = current_cost
            self.nodes_explored += 1
            
            # Goal check
            if node == goal:
                return path, current_cost, self.nodes_explored, self.max_frontier_size
            
            # Explore neighbors
            for neighbor, edge_cost in self.get_neighbors(node):
                new_cost = current_cost + edge_cost
                if neighbor not in visited or new_cost < visited[neighbor]:
                    heapq.heappush(priority_queue, (new_cost, neighbor, path + [neighbor]))
        
        
        return None, None, self.nodes_explored, self.max_frontier_size
    
    def print_graph(self):
        """Utility function to visualize graph structure"""
        print("Graph structure:")
        for node, neighbors in self.graph.items():
            neighbor_str = ", ".join([f"{n}(cost:{c})" for n, c in neighbors])
            print(f"  {node} -> {neighbor_str}")