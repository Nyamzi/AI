"""
Project 0, Task 1: Breadth-First Search - Grid Navigation

Student Name: wanyama David - 2022/BSE/016/PS
Date: [15/10/2025]

Implement BFS to find shortest path through 2D grid with obstacles.
BFS guarantees optimal solution when all step costs are equal.

Key Concepts:
- Uses queue (FIFO) for frontier management
- Explores all nodes at depth d before depth d+1
- Complete and optimal for unweighted graphs
- Time/Space complexity: O(b^d)
"""

from collections import deque

class GridSearchBFS:
    def __init__(self, grid, start, goal):
        """
        Initialize grid search problem
        
        Args:
            grid: 2D list where 0=free, 1=obstacle
            start: tuple (row, col) for starting position
            goal: tuple (row, col) for goal position
        """
        self.grid = grid
        self.rows = len(grid)
        self.cols = len(grid[0]) if grid else 0
        self.start = start
        self.goal = goal
        
        # Statistics tracking
        self.nodes_explored = 0
        self.max_frontier_size = 0
        
    def is_valid_position(self, row, col):
        """
        Check if position is within bounds and not an obstacle
        
        Args:
            row, col: position coordinates
            
        Returns:
            bool: True if position is valid and free
        """
        return (0 <= row < self.rows and 
                0 <= col < self.cols and 
                self.grid[row][col] == 0)
    
    def get_neighbors(self, position):
        """
        Get valid neighboring positions (up, down, left, right)
        
        Args:
            position: tuple (row, col)
            
        Returns:
            list: valid neighboring positions [(row, col), ...]
            
        TODO: Implement this method!
        Hint: Check four directions, use is_valid_position()
        """
        row, col = position
        neighbors = []
        
        # Define four directions: up, down, left, right
        directions = [(-1, 0), (1, 0), (0, -1), (0, 1)]
        
        # TODO: For each direction, check if new position is valid
        # If valid, add to neighbors list
        # Hint: Use self.is_valid_position() to check bounds and obstacles
        
        row, col = position
        neighbors = []

        directions = [(-1, 0), (1, 0), (0, -1), (0, 1)]

        for dr, dc in directions:
            new_row, new_col = row + dr, col + dc
            if self.is_valid_position(new_row, new_col):
                neighbors.append((new_row, new_col))
                
        return neighbors
    
    def breadth_first_search(self):
        """
        Implement BFS algorithm to find shortest path
        
        Returns:
            tuple: (path, nodes_explored, max_frontier_size)
                path: list of positions from start to goal, or None if no path
                nodes_explored: total number of nodes expanded
                max_frontier_size: maximum size of frontier during search
                
        TODO: Implement BFS algorithm!
        
        BFS Algorithm:
        1. Initialize queue with start position and path
        2. Initialize visited set with start position
        3. While queue not empty:
           a. Dequeue position and path
           b. If position is goal, return path
           c. For each neighbor:
              - If not visited, mark visited and enqueue
        4. Return None if no path found
        
        Remember to track statistics!
        """
        # Reset statistics
        self.nodes_explored = 0
        self.max_frontier_size = 0
        
        # Check if start and goal are valid
        if not self.is_valid_position(*self.start) or not self.is_valid_position(*self.goal):
            return None, self.nodes_explored, self.max_frontier_size
        
        # Initialize BFS data structures
        queue = deque([(self.start, [self.start])])  # (position, path_to_position)
        visited = {self.start}
        
        # TODO: Implement BFS main loop
        # Hint: Use queue.popleft() for FIFO behavior
        # Hint: Update statistics (nodes_explored, max_frontier_size)
        # Hint: Check goal condition and explore unvisited neighbors
        
        while queue:
            # Update max frontier size
            self.max_frontier_size = max(self.max_frontier_size, len(queue))
            
            position, path = queue.popleft()
            self.nodes_explored += 1
            
            # Goal check
            if position == self.goal:
                return path, self.nodes_explored, self.max_frontier_size
            
            # Explore neighbors
            for neighbor in self.get_neighbors(position):
                if neighbor not in visited:
                    visited.add(neighbor)
                    queue.append((neighbor, path + [neighbor]))
        
        return None, self.nodes_explored, self.max_frontier_size
    
    def print_grid_with_path(self, path=None):
        """Utility function to visualize grid and solution"""
        if path is None:
            path = []
        
        path_set = set(path)
        
        print("Grid Legend: S=Start, G=Goal, *=Path, #=Obstacle, .=Free")
        for i in range(self.rows):
            row_str = ""
            for j in range(self.cols):
                if (i, j) == self.start:
                    row_str += "S "
                elif (i, j) == self.goal:
                    row_str += "G "
                elif (i, j) in path_set:
                    row_str += "* "
                elif self.grid[i][j] == 1:
                    row_str += "# "
                else:
                    row_str += ". "
            print(row_str)
        
        if path:
            print(f"Path length: {len(path)} steps")
            print(f"Nodes explored: {self.nodes_explored}")
            print(f"Max frontier size: {self.max_frontier_size}")