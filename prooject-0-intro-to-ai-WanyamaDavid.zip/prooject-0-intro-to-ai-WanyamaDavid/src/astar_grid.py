"""
Project 0, Extension: A* Search - Grid Navigation with Heuristics

Student Name: [YOUR NAME HERE]
Date: [DATE]

Implement A* to find optimal path through 2D grid with obstacles using heuristics.
A* combines the optimality of UCS with the efficiency of greedy best-first search.

Key Concepts:
- Uses priority queue ordered by f(n) = g(n) + h(n)
- g(n): actual cost from start to node n
- h(n): heuristic estimate from node n to goal
- Complete and optimal when heuristic is admissible
- Time/Space complexity: O(b^d) but often much better in practice
"""

import heapq
from collections import defaultdict

class GridSearchAStar:
    def __init__(self, grid, start, goal, heuristic='manhattan'):
        """
        Initialize A* grid search problem
        
        Args:
            grid: 2D list where 0=free, 1=obstacle
            start: tuple (row, col) for starting position
            goal: tuple (row, col) for goal position
            heuristic: 'manhattan', 'euclidean', or 'diagonal'
        """
        self.grid = grid
        self.rows = len(grid)
        self.cols = len(grid[0]) if grid else 0
        self.start = start
        self.goal = goal
        self.heuristic_type = heuristic
        
        # Statistics tracking
        self.nodes_explored = 0
        self.max_frontier_size = 0
        
    def is_valid_position(self, row, col):
        """
        Check if position is within bounds and not an obstacle
        
        Args:
            row, col: position coordinates
            
        Returns:
            bool: True if position is valid and free
        """
        return (0 <= row < self.rows and 
                0 <= col < self.cols and 
                self.grid[row][col] == 0)
    
    def get_neighbors(self, position):
        """
        Get valid neighboring positions with movement costs
        
        Args:
            position: tuple (row, col)
            
        Returns:
            list: valid neighboring positions with costs [(neighbor, cost), ...]
        """
        row, col = position
        neighbors = []
        
        # Define four directions: up, down, left, right (unit cost)
        directions = [(-1, 0), (1, 0), (0, -1), (0, 1)]
        
        for dr, dc in directions:
            new_row, new_col = row + dr, col + dc
            if self.is_valid_position(new_row, new_col):
                neighbors.append(((new_row, new_col), 1))  # cost = 1 for basic movement
        
        return neighbors
    
    def heuristic(self, position):
        """
        Calculate heuristic estimate from position to goal
        
        Args:
            position: tuple (row, col)
            
        Returns:
            float: heuristic estimate (must be admissible)
        """
        row1, col1 = position
        row2, col2 = self.goal
        
        if self.heuristic_type == 'manhattan':
            # Manhattan distance (L1 norm) - admissible for 4-connected grid
            return abs(row1 - row2) + abs(col1 - col2)
        
        elif self.heuristic_type == 'euclidean':
            # Euclidean distance (L2 norm) - admissible but less tight for grid
            return ((row1 - row2)**2 + (col1 - col2)**2)**0.5
        
        elif self.heuristic_type == 'diagonal':
            # Chebyshev distance - for 8-connected grid
            return max(abs(row1 - row2), abs(col1 - col2))
        
        else:
            return 0  # Fallback to Dijkstra's algorithm
    
    def astar_search(self):
        """
        Implement A* algorithm to find optimal path
        
        Returns:
            tuple: (path, nodes_explored, max_frontier_size)
                path: list of positions from start to goal, or None if no path
                nodes_explored: total number of nodes expanded
                max_frontier_size: maximum size of frontier during search
        """
        # Reset statistics
        self.nodes_explored = 0
        self.max_frontier_size = 0
        
        # Check if start and goal are valid
        if not self.is_valid_position(*self.start) or not self.is_valid_position(*self.goal):
            return None, self.nodes_explored, self.max_frontier_size
        
        # Priority queue: (f_cost, g_cost, position, path)
        # f_cost = g_cost + h_cost for tie-breaking
        frontier = [(self.heuristic(self.start), 0, self.start, [self.start])]
        heapq.heapify(frontier)
        
        # Keep track of best known costs to each position
        g_costs = defaultdict(lambda: float('inf'))
        g_costs[self.start] = 0
        
        # Keep track of visited nodes (positions we've expanded)
        visited = set()
        
        while frontier:
            # Update max frontier size
            self.max_frontier_size = max(self.max_frontier_size, len(frontier))
            
            # Get node with lowest f-cost
            f_cost, g_cost, current_pos, path = heapq.heappop(frontier)
            
            # Skip if we've already found a better path to this position
            if current_pos in visited:
                continue
                
            # Mark as visited
            visited.add(current_pos)
            self.nodes_explored += 1
            
            # Check if goal reached
            if current_pos == self.goal:
                return path, self.nodes_explored, self.max_frontier_size
            
            # Explore neighbors
            for neighbor, move_cost in self.get_neighbors(current_pos):
                if neighbor in visited:
                    continue
                    
                # Calculate new g-cost
                new_g_cost = g_cost + move_cost
                
                # Skip if we've found a better path to this neighbor
                if new_g_cost >= g_costs[neighbor]:
                    continue
                
                # Update best known cost
                g_costs[neighbor] = new_g_cost
                
                # Calculate f-cost
                h_cost = self.heuristic(neighbor)
                new_f_cost = new_g_cost + h_cost
                
                # Add to frontier
                new_path = path + [neighbor]
                heapq.heappush(frontier, (new_f_cost, new_g_cost, neighbor, new_path))
        
        # No path found
        return None, self.nodes_explored, self.max_frontier_size
    
    def print_grid_with_path(self, path=None):
        """Utility function to visualize grid and solution"""
        if path is None:
            path = []
        
        path_set = set(path)
        
        print("Grid Legend: S=Start, G=Goal, *=Path, #=Obstacle, .=Free")
        for i in range(self.rows):
            row_str = ""
            for j in range(self.cols):
                if (i, j) == self.start:
                    row_str += "S "
                elif (i, j) == self.goal:
                    row_str += "G "
                elif (i, j) in path_set:
                    row_str += "* "
                elif self.grid[i][j] == 1:
                    row_str += "# "
                else:
                    row_str += ". "
            print(row_str)
        
        if path:
            print(f"Path length: {len(path)} steps")
            print(f"Path cost: {len(path) - 1}")
            print(f"Nodes explored: {self.nodes_explored}")
            print(f"Max frontier size: {self.max_frontier_size}")
            print(f"Heuristic used: {self.heuristic_type}")

# Example usage and testing
if __name__ == "__main__":
    # Test with a simple maze
    test_grid = [
        [0, 0, 1, 0, 0],
        [0, 1, 1, 0, 1],
        [0, 0, 0, 0, 0],
        [1, 1, 0, 1, 0],
        [0, 0, 0, 1, 0]
    ]
    
    start = (0, 0)
    goal = (4, 4)
    
    print("=== A* Search Demo ===")
    astar = GridSearchAStar(test_grid, start, goal, 'manhattan')
    path, nodes_explored, max_frontier = astar.astar_search()
    
    if path:
        print("Path found!")
        astar.print_grid_with_path(path)
    else:
        print("No path exists!")
    
    print(f"\nPerformance:")
    print(f"Nodes explored: {nodes_explored}")
    print(f"Max frontier size: {max_frontier}")