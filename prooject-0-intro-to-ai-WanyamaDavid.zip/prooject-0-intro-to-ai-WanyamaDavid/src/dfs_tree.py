"""
Project 0, Task 2: Depth-First Search - Tree Traversal

Student Name: wanyama David - 2022/BSE/016/PS
Date: [15/10/2025]

Implement DFS to traverse tree structures and find target nodes.
DFS explores deeply before backtracking, using less memory than BFS.

Key Concepts:
- Uses stack (LIFO) for frontier management  
- Explores as far as possible before backtracking
- Complete only for finite search spaces
- Not optimal - finds any solution, not necessarily best
- Time: O(b^m), Space: O(bm)
"""
import sys
sys.stdout.reconfigure(encoding='utf-8')

class TreeNode:
    def __init__(self, name, children=None):
        """
        Tree node with name and list of children
        
        Args:
            name: identifier for this node
            children: list of TreeNode children
        """
        self.name = name
        self.children = children or []
        
    def add_child(self, child):
        """Add a child node"""
        self.children.append(child)
        
    def __str__(self):
        return f"TreeNode({self.name})"
        
    def __repr__(self):
        return self.__str__()

class TreeSearchDFS:
    def __init__(self, root, target):
        """
        Initialize tree search problem
        
        Args:
            root: TreeNode representing root of tree
            target: name of target node to find
        """
        self.root = root
        self.target = target
        
        # Statistics tracking
        self.nodes_explored = 0
        self.max_depth_reached = 0
        
    def depth_first_search(self):
        """
        Implement DFS algorithm for tree traversal
        
        Returns:
            tuple: (path, nodes_explored, max_depth_reached)
                path: list of node names from root to target, or None
                nodes_explored: total nodes expanded
                max_depth_reached: deepest level explored
                
        TODO: Implement DFS algorithm!
        
        DFS Algorithm:
        1. Initialize stack with (root, path_to_root, depth)
        2. Initialize visited set (important for graphs with cycles!)
        3. While stack not empty:
           a. Pop node, path, and depth
           b. If node name matches target, return path
           c. Mark node as visited
           d. For each child (in reverse order for left-first traversal):
              - If not visited, push to stack
        4. Return None if target not found
        
        Note: For tree (no cycles), visited set isn't strictly necessary,
        but it's good practice for general graph search.
        """
        # Reset statistics
        self.nodes_explored = 0
        self.max_depth_reached = 0
        
        if not self.root:
            return None, self.nodes_explored, self.max_depth_reached
        
        # Initialize DFS data structures
        stack = [(self.root, [self.root.name], 0)]  # (node, path, depth)
        visited = set()
        
        # TODO: Implement DFS main loop
        # Hint: Use stack.pop() for LIFO behavior
        # Hint: Update statistics (nodes_explored, max_depth_reached) 
        # Hint: Check target condition and explore unvisited children
        # Hint: Add children in reverse order for left-first traversal
        
        while stack:
            node, path, depth = stack.pop()  # LIFO
            self.nodes_explored += 1
            self.max_depth_reached = max(self.max_depth_reached, depth)
            
            # Check goal condition
            if node.name == self.target:
                return path, self.nodes_explored, self.max_depth_reached
            
            visited.add(node)
            
            # Explore children in reverse order for left-first traversal
            for child in reversed(node.children):
                if child not in visited:
                    stack.append((child, path + [child.name], depth + 1))
        
        return None, self.nodes_explored, self.max_depth_reached
    
    def print_tree(self, node=None, level=0, prefix=""):
        """Utility function to visualize tree structure"""
        if node is None:
            node = self.root
            
        print(f"{'  ' * level}{prefix}{node.name}")
        
        for i, child in enumerate(node.children):
            is_last = (i == len(node.children) - 1)
            child_prefix = "└── " if is_last else "├── "
            self.print_tree(child, level + 1, child_prefix)