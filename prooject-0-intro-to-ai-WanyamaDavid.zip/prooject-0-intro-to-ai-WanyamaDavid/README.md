[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/Z5XPQnQf)
# Project 0: Uninformed Search Algorithm

Master the fundamental search algorithms that power AI problem-solving! 🔍

##  Quick Start Guide

### Step 1: Get the Code
1. **Accept assignment** via GitHub Classroom link
2. **Clone your repository**:
   ```bash
   git clone [your-repo-url]
   cd project0-search-algorithms
   ```

### Step 2: Set Up Environment
```bash
# Install Python dependencies
pip install -r requirements.txt

# Verify setup works
python verify_setup.py
```

### Step 3: Understand the Task
- Read [`docs/INSTRUCTIONS.md`](docs/INSTRUCTIONS.md) for detailed requirements
- Look at [`docs/GRADING_RUBRIC.md`](docs/GRADING_RUBRIC.md) for grading criteria
- Examine the starter code in `src/` directory

### Step 4: Implement & Test
1. Complete the TODO sections in `src/bfs_grid.py`, `src/dfs_tree.py`, `src/ucs_graph.py`
2. Test each implementation as you go
3. Complete the performance analysis
4. Submit via Git

## 🎯 What You'll Learn

By completing this project, you will master:

- **Core Search Algorithms**: Understand how BFS, DFS, and UCS work internally
- **Data Structures**: Practice with queues, stacks, and priority queues
- **Algorithm Analysis**: Learn to evaluate completeness, optimality, and complexity
- **Problem Modeling**: Represent real-world problems as search spaces
- **Performance Evaluation**: Compare algorithms empirically
- **Code Implementation**: Write clean, efficient Python code

## 📋 Assignment Overview

### What You'll Implement

#### Required Algorithms (75 points)
- 🗺️ **Breadth-First Search (BFS)**: Grid navigation with obstacle avoidance (25 points)
  - *File*: `src/bfs_grid.py`
  - *Problem*: Navigate a robot through a 2D grid maze
  - *Key Learning*: FIFO queue, shortest path guarantee

- 🌳 **Depth-First Search (DFS)**: Tree traversal and pathfinding (25 points)
  - *File*: `src/dfs_tree.py`
  - *Problem*: Find target nodes in tree structures
  - *Key Learning*: LIFO stack, memory efficiency vs optimality

- 💰 **Uniform Cost Search (UCS)**: Optimal pathfinding in weighted graphs (25 points)
  - *File*: `src/ucs_graph.py`
  - *Problem*: Find lowest-cost paths through weighted networks
  - *Key Learning*: Priority queues, handling variable action costs

#### Analysis & Reporting (25 points)
- 📊 **Algorithm Comparison**: Performance analysis across problem types
  - *File*: `analysis/algorithm_comparison.py`
  - *Report*: `analysis/search_analysis.md`
  - *Key Learning*: Empirical evaluation, trade-off analysis

#### Bonus Extensions (Up to 55 points)
- ⭐ **A* Search**: Informed pathfinding with heuristics (20 points)
  - *File*: `src/astar_grid.py` (already implemented as example!)
  - *Key Learning*: Heuristic functions, informed vs uninformed search

- 🔄 **Iterative Deepening DFS**: Combine DFS memory efficiency with BFS optimality (10 points)
  - *Key Learning*: Progressive depth limits, space-time trade-offs

- ↔️ **Bidirectional Search**: Search from both start and goal simultaneously (15 points)  
  - *Key Learning*: Meeting point detection, performance optimization

- 🎨 **Search Visualization**: Create animations of algorithm exploration (10 points)
  - *Key Learning*: Algorithm understanding through visual representation

### Project Structure Explained

```
📁 Project Root
├── 📄 README.md                    ← This file
├── 📄 requirements.txt             ← Python dependencies
├── 📄 verify_setup.py              ← Setup verification script
├── 📁 src/                         ← YOUR IMPLEMENTATIONS GO HERE
│   ├── 📄 bfs_grid.py             ← TODO: Complete BFS
│   ├── 📄 dfs_tree.py             ← TODO: Complete DFS  
│   ├── 📄 ucs_graph.py            ← TODO: Complete UCS
│   └── 📄 astar_grid.py           ← ✅ Complete A* example
├── 📁 tests/                       ← Test your implementations
│   ├── 📄 test_bfs.py             ← BFS test cases
│   ├── 📄 test_dfs.py             ← DFS test cases
│   ├── 📄 test_ucs.py             ← UCS test cases
│   ├── 📄 test_astar.py           ← A* test cases
│   └── 📄 test_all.py             ← Run all tests
├── 📁 problems/                    ← Problem definitions
│   └── 📄 sample_problems.py      ← Test problem generators
├── 📁 docs/                        ← Detailed documentation
│   ├── 📄 INSTRUCTIONS.md         ← Complete assignment instructions
│   └── 📄 GRADING_RUBRIC.md       ← How you'll be graded
└── 📁 analysis/                    ← Performance analysis
    ├── 📄 algorithm_comparison.py  ← TODO: Complete comparison
    └── 📄 search_analysis.md       ← TODO: Write your analysis
```

## ⚙️ Setup Instructions

### Prerequisites
- Python 3.8 or higher
- Git for version control
- Text editor or IDE (VS Code recommended)

### Environment Setup

#### Option 1: Using pip (Recommended)
```bash
# Navigate to project directory
cd project0-search-algorithms

# Install dependencies
pip install -r requirements.txt

# Verify installation
python verify_setup.py
```

#### Option 2: Using conda
```bash
# Create conda environment
conda create -n search-algorithms python=3.9
conda activate search-algorithms

# Install dependencies
pip install -r requirements.txt

# Verify installation
python verify_setup.py
```

### Verification
Run the setup verification script:
```bash
python verify_setup.py
```

You should see:
```
🎉 ALL CHECKS PASSED!
Your project structure is correctly set up.
```

## 💻 Implementation Guide

### Understanding the Starter Code

Each algorithm file contains:
- **Class definition** with initialization and helper methods
- **Main algorithm method** with detailed TODO comments
- **Utility methods** for visualization and debugging
- **Extensive comments** explaining the algorithm logic

### Implementation Strategy

#### 1. Start with BFS (`src/bfs_grid.py`)
```python
# Key areas to complete:
def get_neighbors(self, position):
    # TODO: Return valid adjacent positions

def breadth_first_search(self):
    # TODO: Implement BFS main loop
```

**Tips for BFS:**
- Use `collections.deque` for the queue
- Track visited positions to avoid cycles
- Remember FIFO: first in, first out
- Update statistics as you go

#### 2. Move to DFS (`src/dfs_tree.py`)
```python
# Key areas to complete:
def depth_first_search(self):
    # TODO: Implement DFS main loop
```

**Tips for DFS:**
- Use a regular list as stack (append/pop)
- Track visited nodes to avoid infinite loops
- Remember LIFO: last in, first out
- Explore children in consistent order

#### 3. Implement UCS (`src/ucs_graph.py`)
```python
# Key areas to complete:
def uniform_cost_search(self, start, goal):
    # TODO: Implement UCS main loop
```

**Tips for UCS:**
- Use `heapq` for priority queue
- Track best costs to each node
- Only expand nodes when reached optimally
- Handle multiple paths to same node correctly

### Step-by-Step Implementation Process

1. **Read the TODO comments carefully** - they contain algorithm pseudocode
2. **Start small** - implement basic functionality first
3. **Test frequently** - run tests after each major addition
4. **Debug methodically** - use print statements to trace execution
5. **Validate results** - ensure your paths are actually valid

### Common Implementation Patterns

#### Queue/Stack Management
```python
# BFS Queue
from collections import deque
queue = deque([(start, [start])])
current, path = queue.popleft()  # FIFO

# DFS Stack  
stack = [(start, [start])]
current, path = stack.pop()      # LIFO

# UCS Priority Queue
import heapq
pq = [(0, start, [start])]
cost, current, path = heapq.heappop(pq)
```

#### Neighbor Exploration
```python
for neighbor in get_neighbors(current):
    if neighbor not in visited:
        new_path = path + [neighbor]
        # Add to frontier (queue/stack/priority queue)
```

#### Statistics Tracking
```python
# Update these throughout your algorithm
self.nodes_explored += 1
self.max_frontier_size = max(self.max_frontier_size, len(frontier))
```

## 🧪 Testing Your Code

### Testing Strategy

#### 1. Individual Algorithm Testing
Test each algorithm as you implement it:

```bash
# Test BFS implementation
python tests/test_bfs.py

# Test DFS implementation  
python tests/test_dfs.py

# Test UCS implementation
python tests/test_ucs.py

# Test A* (already working)
python tests/test_astar.py
```

#### 2. Comprehensive Testing
Once all algorithms work:

```bash
# Run all algorithm tests
python tests/test_all.py

# Run performance comparison
python analysis/algorithm_comparison.py
```

### Understanding Test Output

#### Successful BFS Test:
```
Path found: [(0, 0), (0, 1), (1, 1), (2, 1), (2, 2)]
Nodes explored: 5
Max frontier size: 3
```

#### Failed Test (before implementation):
```
Path found: None
Nodes explored: 0
Max frontier size: 0
```

### Test Cases Explained

Each algorithm is tested on:
- **Simple cases**: Basic functionality verification
- **Complex cases**: Challenging problems that stress the algorithm
- **Edge cases**: No solution, invalid inputs, single nodes
- **Performance cases**: Measure efficiency and optimality

### Debugging Tips

#### Common Issues and Solutions

1. **"Path found: None" but should find path**
   - Check if you're adding neighbors to frontier
   - Verify visited set logic
   - Ensure goal checking is correct

2. **Infinite loops or very slow execution**
   - Make sure you're marking nodes as visited
   - Check that you're not revisiting same nodes
   - Verify frontier management

3. **Path is invalid (gaps or obstacles)**
   - Check neighbor generation logic
   - Verify path reconstruction
   - Ensure valid position checking

4. **Non-optimal paths (UCS/A*)**
   - Check priority queue ordering
   - Verify cost calculations
   - Ensure proper handling of multiple paths

#### Debugging Code Example
```python
# Add debugging prints to trace execution
print(f"Exploring: {current_pos}")
print(f"Frontier size: {len(frontier)}")
print(f"Path so far: {path}")
```

## 📝 Submission Guidelines

### What to Submit

#### 1. Implementation Files (75 points)
- ✅ `src/bfs_grid.py` - Complete BFS implementation
- ✅ `src/dfs_tree.py` - Complete DFS implementation  
- ✅ `src/ucs_graph.py` - Complete UCS implementation

#### 2. Analysis Components (25 points)
- ✅ `analysis/algorithm_comparison.py` - Working performance comparison
- ✅ `analysis/search_analysis.md` - Completed analysis report (750+ words)

#### 3. Evidence of Testing
- All tests should pass: `python tests/test_all.py`
- Include any additional test cases you created

### Submission Checklist

Before submitting, verify:

- [ ] **Implementation Complete**
  - [ ] BFS finds shortest paths in all test grids
  - [ ] DFS properly traverses trees without infinite loops
  - [ ] UCS finds optimal cost paths in weighted graphs
  - [ ] All algorithms handle edge cases (no solution, invalid inputs)

- [ ] **Testing Passed**
  - [ ] `python tests/test_all.py` shows all tests passing
  - [ ] `python analysis/algorithm_comparison.py` runs without errors
  - [ ] Performance statistics are reasonable (not all zeros)

- [ ] **Analysis Complete**
  - [ ] Algorithm comparison data filled in
  - [ ] Analysis report addresses all required sections
  - [ ] Word count meets minimum requirement (750+ words)
  - [ ] Real-world applications discussed

- [ ] **Code Quality**
  - [ ] Code is clean and readable
  - [ ] No syntax errors or warnings
  - [ ] Comments explain complex logic
  - [ ] Variable names are descriptive

- [ ] **Submission Ready**
  - [ ] All files committed to Git
  - [ ] Repository pushed to GitHub
  - [ ] No temporary or backup files included
  - [ ] README updated with your name/info if required

### Submission Commands

```bash
# Check your changes
git status

# Add all changes
git add .

# Commit with descriptive message
git commit -m "Complete Project 0: Implement BFS, DFS, UCS algorithms and analysis"

# Push to GitHub
git push origin main
```

## 🆘 Getting Help

### When You're Stuck

#### 1. Check the Documentation
- Read `docs/INSTRUCTIONS.md` for detailed guidance
- Review the TODO comments in starter code
- Look at the working A* implementation for reference

#### 2. Debug Systematically
- Add print statements to trace algorithm execution
- Test with simple cases first
- Verify each component (neighbors, visited set, frontier) separately

#### 3. Common Resources
- **Textbook**: Russell & Norvig Chapter 3 (Uninformed Search)
- **Online**: Algorithm visualizations at [VisuAlgo](https://visualgo.net/)
- **Course Materials**: Lecture slides

#### 4. Ask for Help
- **Office Hours**: Fridays 10:00 - 11:30 am
- **Study Groups**: Discuss concepts (not code) with classmates

### Frequently Asked Questions

#### Q: Can I use additional Python libraries?
A: Stick to the standard library and provided imports. The algorithms should work with `collections`, `heapq`, and basic Python.

#### Q: How do I know if my algorithm is correct?
A: Your implementation is correct if:
- All tests pass (`python tests/test_all.py`)
- Paths are valid (no gaps, no obstacles)
- Statistics are reasonable (nodes explored > 0)
- Results match expected behavior

#### Q: What if my algorithm is very slow?
A: Check for:
- Infinite loops (missing visited set)
- Inefficient data structures
- Redundant path checking
- Large search spaces (normal for some problems)

#### Q: Can I look at the A* implementation?
A: Yes! The A* code (`src/astar_grid.py`) is provided as a complete reference. Study it to understand:
- Proper priority queue usage
- Statistics tracking
- Edge case handling
- Code organization

### Academic Integrity

#### ✅ Allowed:
- Discussing algorithm concepts with classmates
- Using textbook and online algorithm resources  
- Getting help debugging from TAs/instructor
- Looking at the provided A* implementation
- Studying algorithm pseudocode

#### ❌ Not Allowed:
- Copying code from classmates or online sources
- Sharing complete solutions with others
- Using external algorithm implementations
- Submitting work that is not substantially your own

### Success Tips

1. **Start Early**: This project builds foundational skills - don't rush
2. **Test Incrementally**: Test each method as you implement it
3. **Understand, Don't Memorize**: Focus on why algorithms work, not just how
4. **Use the A* Example**: Study the complete implementation for patterns
5. **Ask Questions**: If confused, ask for clarification early

*Good luck!* 
