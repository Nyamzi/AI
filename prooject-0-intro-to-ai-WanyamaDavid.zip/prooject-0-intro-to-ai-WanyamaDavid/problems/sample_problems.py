"""
Sample problems for testing search algorithms

This file contains various test cases you can use to evaluate your implementations.
"""

def get_simple_grid():
    """Simple 3x3 grid with one obstacle"""
    return [
        [0, 0, 0],
        [0, 1, 0], 
        [0, 0, 0]
    ], (0, 0), (2, 2)

def get_maze_grid():
    """5x5 maze grid"""
    return [
        [0, 0, 1, 0, 0],
        [0, 1, 1, 0, 1],
        [0, 0, 0, 0, 0],
        [1, 1, 0, 1, 0],
        [0, 0, 0, 1, 0]
    ], (0, 0), (4, 4)

def get_no_solution_grid():
    """Grid with no solution"""
    return [
        [0, 1, 0],
        [1, 1, 1],
        [0, 1, 0]
    ], (0, 0), (2, 2)

def get_sample_tree():
    """Create sample tree structure"""
    import sys
    import os
    sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'src'))
    from dfs_tree import TreeNode
    
    #       A
    #      /|\
    #     B C D
    #    /  |  \
    #   E   F   G
    #      /|\
    #     H I J
    
    root = TreeNode('A')
    b = TreeNode('B')
    c = TreeNode('C')
    d = TreeNode('D')
    e = TreeNode('E')
    f = TreeNode('F')
    g = TreeNode('G')
    h = TreeNode('H')
    i = TreeNode('I')
    j = TreeNode('J')
    
    root.children = [b, c, d]
    b.children = [e]
    c.children = [f]
    d.children = [g]
    f.children = [h, i, j]
    
    return root

def get_weighted_graph():
    """Create sample weighted graph"""
    return {
        'A': [('B', 2), ('C', 3)],
        'B': [('D', 1), ('E', 4)],
        'C': [('E', 1)],
        'D': [('F', 2)],
        'E': [('F', 3)],
        'F': []
    }

def get_complex_graph():
    """Create more complex weighted graph"""
    return {
        'S': [('A', 1), ('B', 4)],
        'A': [('B', 2), ('C', 5), ('D', 12)],
        'B': [('C', 2)],
        'C': [('D', 3)],
        'D': []
    }