# Project 0: Technical Implementation Guide

📋 **For project overview and setup, see [`../README.md`](../README.md)**

## Algorithm Specifications

This document provides detailed technical requirements for implementing BFS, DFS, and UCS algorithms.

## Algorithm Properties Summary

| Algorithm | Data Structure | Time Complexity | Space Complexity | Complete | Optimal |
|-----------|----------------|-----------------|------------------|----------|---------|
| BFS | Queue (FIFO) | O(b^d) | O(b^d) | ✅ Yes | ✅ Yes* |
| DFS | Stack (LIFO) | O(b^m) | O(bm) | ✅ Finite** | ❌ No |
| UCS | Priority Queue | O(b^(C*/ε)) | O(b^(C*/ε)) | ✅ Yes | ✅ Yes |

*BFS optimal for unweighted graphs  
**DFS complete only for finite search spaces

### When to Use Each Algorithm

- **BFS**: Shortest path in unweighted graphs, level-by-level exploration
- **DFS**: Memory-constrained environments, finding any solution quickly
- **UCS**: Weighted graphs where optimal cost matters

## Detailed Implementation Requirements

### Task 1: BFS - Grid Navigation 🗺️

**File**: `src/bfs_grid.py`

**Problem**: Navigate robot through 2D grid from start to goal, avoiding obstacles.

#### Implementation Requirements

**Data Structures**:
- Queue: `collections.deque` for FIFO behavior
- Visited set: Track explored positions to avoid cycles
- Path tracking: Store complete path to each position

**Algorithm Steps**:
1. Initialize queue with `(start_position, [start_position])`
2. Initialize visited set with start position
3. While queue not empty:
   - Dequeue position and path
   - If position == goal, return path
   - For each valid neighbor:
     - If not visited, mark visited and enqueue with extended path

**Required Methods**:
```python
def get_neighbors(self, position):
    # Return valid adjacent positions (up, down, left, right)
    # Check bounds and obstacles
    
def breadth_first_search(self):
    # Main BFS algorithm
    # Return (path, nodes_explored, max_frontier_size)
```

**Statistics Tracking**:
- `nodes_explored`: Increment each time you dequeue a position
- `max_frontier_size`: Track maximum queue size during search

**Edge Cases**:
- Invalid start/goal positions (out of bounds or obstacles)
- No path exists between start and goal
- Start equals goal

### Task 2: DFS - Tree Traversal 🌳

**File**: `src/dfs_tree.py`

**Problem**: Find target node in tree structure using depth-first exploration.

#### Implementation Requirements

**Data Structures**:
- Stack: Python list using `append()`/`pop()` for LIFO behavior
- Visited set: Track explored nodes to prevent infinite loops
- Path tracking: Store complete path to each node

**Algorithm Steps**:
1. Initialize stack with `(root_node, [root_name], 0)` (node, path, depth)
2. Initialize visited set
3. While stack not empty:
   - Pop node, path, and depth
   - If node.name == target, return path
   - Mark node as visited
   - For each child (in reverse order for left-first traversal):
     - If not visited, push to stack with extended path and incremented depth

**Required Methods**:
```python
def depth_first_search(self):
    # Main DFS algorithm  
    # Return (path, nodes_explored, max_depth_reached)
```

**Statistics Tracking**:
- `nodes_explored`: Increment each time you pop from stack
- `max_depth_reached`: Track maximum depth visited during search

**Important Notes**:
- Explore children in reverse order to ensure left-first traversal
- Use visited set even for trees to demonstrate proper graph search
- Handle trees that may have been converted to graphs (cycles possible)

### Task 3: UCS - Weighted Graph Search 💰

**File**: `src/ucs_graph.py`

**Problem**: Find lowest-cost path through weighted graph.

#### Implementation Requirements

**Data Structures**:
- Priority Queue: `heapq` with `(cost, node, path)` tuples
- Visited dictionary: Track best cost to reach each node
- Path tracking: Store complete path with total cost

**Algorithm Steps**:
1. Initialize priority queue with `(0, start, [start])`
2. Initialize visited dictionary
3. While priority queue not empty:
   - Pop lowest cost `(current_cost, node, path)`
   - If node in visited with better cost, skip
   - Mark node as visited with current cost
   - If node == goal, return path and cost
   - For each neighbor with edge cost:
     - Calculate new_cost = current_cost + edge_cost
     - If neighbor not visited or new_cost better, add to queue

**Required Methods**:
```python
def uniform_cost_search(self, start, goal):
    # Main UCS algorithm
    # Return (path, total_cost, nodes_explored, max_frontier_size)
```

**Critical UCS Details**:
- **Only expand nodes when reached via optimal path**
- Use visited dictionary to track best known cost to each node
- Multiple paths to same node are normal - only process the optimal one
- Priority queue automatically orders by cost (heapq is min-heap)

**Statistics Tracking**:
- `nodes_explored`: Increment when processing a node (not when adding to queue)
- `max_frontier_size`: Track maximum priority queue size

### Task 4: Algorithm Comparison 📊

**File**: `analysis/algorithm_comparison.py`

**Goal**: Run all algorithms on same problems and compare performance.

**Required Analysis**:
- Solution quality (path length/cost)
- Efficiency (nodes explored)  
- Memory usage (max frontier size)
- Execution time comparison
- Optimality verification

## Testing and Debugging Guide

### Test Cases Breakdown

#### BFS Grid Tests
- **Simple 3x3 grid**: Basic functionality verification
- **Complex 5x5 maze**: Performance under challenging conditions
- **No solution grid**: Goal unreachable from start
- **Edge cases**: Invalid positions, start=goal, obstacles

#### DFS Tree Tests  
- **Root finding**: Target is the root node
- **Leaf finding**: Target is a leaf node
- **Non-existent target**: Target not in tree
- **Deep trees**: Test depth tracking and memory efficiency

#### UCS Graph Tests
- **Simple weighted graph**: Basic cost optimization
- **Multiple path scenarios**: Verify optimal path selection
- **Uniform cost graph**: Should match BFS behavior
- **Complex networks**: Stress test with many nodes and edges

### Understanding Test Output

#### Before Implementation (Expected):
```
Testing BFS Grid Navigation
Path found: None
Nodes explored: 0
Max frontier size: 0
```

#### After Correct Implementation:
```
Testing BFS Grid Navigation
Path found: [(0, 0), (0, 1), (1, 1), (2, 1), (2, 2)]
Path length: 5 steps
Nodes explored: 8
Max frontier size: 3
```

### Common Implementation Issues

#### Issue 1: "Path found: None" when path should exist
**Symptoms**: All tests return None, nodes_explored = 0
**Causes**:
- Not adding neighbors to frontier
- Incorrect goal checking logic
- Frontier becomes empty prematurely

**Debug Steps**:
```python
# Add debug prints to trace execution
print(f"Current position: {current_pos}")
print(f"Goal position: {self.goal}")
print(f"Neighbors found: {neighbors}")
print(f"Frontier size: {len(frontier)}")
```

#### Issue 2: Infinite loops or very slow execution
**Symptoms**: Program hangs or takes extremely long
**Causes**:
- Missing or incorrect visited set logic
- Not marking nodes as visited
- Revisiting same nodes repeatedly

**Debug Steps**:
```python
# Check visited set behavior
print(f"Visited: {visited}")
print(f"Current in visited: {current in visited}")
```

#### Issue 3: Invalid paths (gaps in path)
**Symptoms**: Path contains non-adjacent positions
**Causes**:
- Incorrect neighbor generation
- Wrong path reconstruction logic
- Skipping validation checks

**Debug Steps**:
```python
# Validate path continuity
for i in range(len(path) - 1):
    current = path[i]
    next_pos = path[i + 1]
    distance = abs(current[0] - next_pos[0]) + abs(current[1] - next_pos[1])
    assert distance == 1, f"Invalid step from {current} to {next_pos}"
```

#### Issue 4: Non-optimal paths (UCS/BFS)
**Symptoms**: Algorithm finds path but not optimal one
**Causes**:
- Incorrect priority queue ordering
- Wrong cost calculations
- Not handling multiple paths properly

**Debug Steps**:
```python
# Track costs and decisions
print(f"Processing node {node} with cost {cost}")
print(f"Best known cost to {node}: {visited.get(node, 'unknown')}")
```

### Debugging Strategies

#### 1. Start Small
- Test with minimal examples first
- Use simple 2x2 or 3x3 grids for BFS
- Use small trees for DFS
- Use 3-4 node graphs for UCS

#### 2. Trace Algorithm Execution
```python
def breadth_first_search(self):
    print(f"Starting BFS from {self.start} to {self.goal}")
    
    while queue:
        current_pos, path = queue.popleft()
        print(f"Exploring: {current_pos}, Path: {path}")
        
        if current_pos == self.goal:
            print(f"Goal found! Final path: {path}")
            return path
```

#### 3. Validate Data Structures
```python
# Check queue/stack operations
print(f"Queue after adding neighbors: {list(queue)}")
print(f"Stack top: {stack[-1] if stack else 'empty'}")
print(f"Priority queue: {priority_queue}")
```

#### 4. Test Individual Components
```python
# Test neighbor generation separately
neighbors = self.get_neighbors((1, 1))
print(f"Neighbors of (1,1): {neighbors}")

# Test position validation
print(f"(0,0) valid: {self.is_valid_position(0, 0)}")
print(f"(-1,0) valid: {self.is_valid_position(-1, 0)}")
```

### Performance Expectations

#### Typical Results for Test Cases

**BFS 5x5 Maze**:
- Path length: 8-12 steps
- Nodes explored: 10-20
- Max frontier: 3-8

**DFS Small Tree**:
- Path length: varies (not optimal)
- Nodes explored: 3-8
- Max depth: 2-4

**UCS Weighted Graph**:
- Optimal cost: depends on graph
- Nodes explored: fewer than BFS for same graph
- Should find truly optimal cost path

#### Warning Signs
- `nodes_explored = 0`: Algorithm not running
- `max_frontier_size = 0`: Frontier management issue
- Path length > 2 * grid diagonal: Likely suboptimal
- Execution time > 1 second for small problems: Efficiency issue

## Implementation Validation Checklist

### Before Submitting - Verify Your Implementation

#### BFS Validation ✅
- [ ] Uses `collections.deque` for queue (FIFO behavior)
- [ ] Finds shortest path in grid navigation
- [ ] Returns `(path, nodes_explored, max_frontier_size)`
- [ ] Handles edge cases: no path, invalid positions
- [ ] Path is valid: adjacent positions only, no obstacles
- [ ] Statistics reasonable: nodes_explored > 0 for solvable problems

#### DFS Validation ✅  
- [ ] Uses list as stack with `append()`/`pop()` (LIFO behavior)
- [ ] Explores to appropriate depths before backtracking
- [ ] Returns `(path, nodes_explored, max_depth_reached)`
- [ ] Uses visited set to prevent infinite loops
- [ ] Explores children in consistent order (left-first)
- [ ] Handles trees and graphs with cycles

#### UCS Validation ✅
- [ ] Uses `heapq` for priority queue ordered by cost
- [ ] Finds optimal (lowest cost) paths
- [ ] Returns `(path, total_cost, nodes_explored, max_frontier_size)`
- [ ] Only expands nodes when reached via optimal path
- [ ] Handles multiple paths to same node correctly
- [ ] Cost calculations are accurate

#### Algorithm Comparison ✅
- [ ] Runs all algorithms on same test problems
- [ ] Compares path quality, efficiency, and memory usage
- [ ] Analysis report addresses all required sections
- [ ] Real-world applications discussed
- [ ] Word count meets minimum (750+ words)

### Final Testing Commands

```bash
# Verify all implementations work
python tests/test_all.py

# Check algorithm comparison
python analysis/algorithm_comparison.py

# Verify project structure
python verify_setup.py
```

### Code Quality Standards

- **Clean Code**: Readable variable names, proper indentation
- **Comments**: Explain complex logic and algorithm steps  
- **Error Handling**: Graceful handling of edge cases
- **Efficiency**: No unnecessary computation or infinite loops
- **Consistency**: Follow existing code style and patterns

📋 **For submission checklist and grading details, see [`GRADING_RUBRIC.md`](GRADING_RUBRIC.md)**

## Bonus Extensions (Optional)

### A* Search Implementation (20 pts)
- **File**: `src/astar_grid.py` (already provided as complete example!)
- **Goal**: Study the implementation to understand informed search
- **Learning**: Heuristic functions, f(n) = g(n) + h(n), admissibility

### Additional Challenges (10-15 pts each)
- **Iterative Deepening DFS**: Combine DFS memory efficiency with BFS optimality
- **Bidirectional Search**: Search from both start and goal simultaneously  
- **Search Visualization**: Create animations of algorithm exploration
- **Custom Heuristics**: Experiment with different A* heuristic functions

📖 **For detailed bonus requirements, see [`GRADING_RUBRIC.md`](GRADING_RUBRIC.md)**

---

## Quick Reference

### Essential Data Structures
```python
# BFS
from collections import deque
queue = deque([(start, [start])])

# DFS  
stack = [(start, [start], 0)]

# UCS
import heapq
pq = [(0, start, [start])]
```
**Remember**: The A* implementation in `src/astar_grid.py` is your best reference for complete, working code patterns!