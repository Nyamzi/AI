# Project 0: Grading Rubric - Search Algorithms

**Total Points: 100 + up to 55 bonus points**

## Core Requirements (100 points)

### 1. Breadth-First Search Implementation (25 points)

**Excellent (23-25 pts)**:
- Correctly implements BFS using queue (FIFO)
- Finds shortest path in all test cases
- Proper visited set management
- Accurate statistics tracking (nodes explored, frontier size)
- Handles edge cases (no path, invalid positions)
- Clean, well-commented code

**Good (18-22 pts)**:
- Mostly correct BFS with minor issues
- Finds correct paths on most test cases
- Minor problems with statistics or edge cases

**Satisfactory (12-17 pts)**:
- Basic BFS functionality present
- May not handle all edge cases correctly
- Some test cases fail

**Needs Improvement (0-11 pts)**:
- Major algorithmic errors
- Doesn't use proper queue structure
- Most test cases fail

### 2. Depth-First Search Implementation (25 points)

**Excellent (23-25 pts)**:
- Correctly implements DFS using stack (LIFO)
- Proper cycle detection with visited set
- Finds valid paths without infinite loops
- Explores to appropriate depths
- Consistent child exploration order
- Accurate depth and node tracking

**Good (18-22 pts)**:
- Mostly correct DFS with minor issues
- May have small problems with cycle detection

**Satisfactory (12-17 pts)**:
- Basic DFS functionality
- May get stuck in cycles or miss some paths

**Needs Improvement (0-11 pts)**:
- Major algorithmic errors
- Infinite loops or incorrect traversal

### 3. Uniform Cost Search Implementation (25 points)

**Excellent (23-25 pts)**:
- Correctly implements UCS using priority queue
- Finds optimal (lowest cost) paths in all cases
- Proper handling of multiple paths to same node
- Only expands nodes when reached via optimal path
- Accurate cost calculations and tracking
- Handles negative costs gracefully

**Good (18-22 pts)**:
- Mostly correct UCS with minor cost calculation issues
- Finds optimal paths in most test cases

**Satisfactory (12-17 pts)**:
- Basic priority queue usage
- May not handle multiple paths correctly

**Needs Improvement (0-11 pts)**:
- Major errors in priority queue or cost handling
- Does not find optimal paths

### 4. Analysis Report (25 points)

**Excellent (23-25 pts)**:
- **Algorithm Analysis**: Clear comparison of completeness, optimality, complexity
- **Empirical Results**: Thorough analysis of performance data
- **Trade-offs**: Insightful discussion of memory vs quality vs speed
- **Applications**: Relevant real-world examples
- **Writing**: 750+ words, well-organized, professional
- **Code Quality**: All tests pass, clean implementations

**Good (18-22 pts)**:
- Addresses most required sections with good insight
- Minor gaps in analysis or writing
- Most tests pass with minor issues

**Satisfactory (12-17 pts)**:
- Basic coverage of required topics
- Limited depth of analysis
- Some tests pass, basic code quality

**Needs Improvement (0-11 pts)**:
- Missing sections or superficial analysis
- Poor writing quality
- Many test failures

## Bonus Challenges (Up to 55 points)

### Challenge 1: Iterative Deepening DFS (10 points)
- Correct implementation of IDDFS
- Combines DFS space efficiency with BFS optimality
- Proper depth limit management

### Challenge 2: Bidirectional Search (15 points)
- Searches from both start and goal
- Correct meeting point detection
- Significant performance improvement on appropriate problems

### Challenge 3: Search Visualization (10 points)
- Clear visual representation of search process
- Shows frontier expansion over time
- Interactive or animated display

### Challenge 4: A* Search Implementation (20 points)
- Correct A* implementation with admissible heuristic
- Demonstrates understanding of informed search
- Outperforms uninformed search on test problems

## Detailed Evaluation Criteria

### Algorithm Correctness
- **Completeness**: Does algorithm find solution when one exists?
- **Optimality**: Does algorithm find best solution (when applicable)?
- **Termination**: Does algorithm terminate on all inputs?
- **Edge Cases**: Handles invalid inputs, no solution cases

### Implementation Quality  
- **Data Structures**: Proper use of queue, stack, priority queue
- **Efficiency**: Reasonable performance on test cases
- **Memory Management**: Appropriate space usage
- **Code Style**: Readable, maintainable, documented

### Understanding Demonstration
- **Algorithm Analysis**: Shows understanding of theoretical properties
- **Empirical Analysis**: Meaningful interpretation of results
- **Trade-off Discussion**: Recognizes when to use each algorithm
- **Real-world Connection**: Links to practical applications

## Test Case Categories

### BFS Grid Tests
- Simple 5x5 grids with few obstacles
- Complex 10x10 maze-like structures
- No solution cases (completely blocked)
- Edge cases (start=goal, start/goal invalid)

### DFS Tree Tests
- Binary trees of various depths
- Wide trees requiring backtracking
- Trees with cycles (converted to graphs)
- Target at different depths

### UCS Graph Tests
- Simple weighted graphs
- Cases where shortest path ≠ lowest cost
- Graphs with uniform costs (should match BFS)
- Complex multi-path networks

## Submission Requirements

### File Structure Check
```
src/
├── bfs_grid.py          ✓ Complete implementation
├── dfs_tree.py          ✓ Complete implementation  
├── ucs_graph.py         ✓ Complete implementation
analysis/
├── algorithm_comparison.py  ✓ Working comparison
└── search_analysis.md   ✓ 750+ word report
```

### GitHub Submission
- [ ] All files committed and pushed
- [ ] Repository accessible to instructors  
- [ ] No missing files or broken imports
- [ ] Clean commit history

## Late Policy
- **1 day late**: -10%
- **2 days late**: -20%
- **3+ days late**: -30%
- **After 1 week**: Must contact instructor

## Academic Integrity
- ✅ Discuss algorithm concepts with classmates
- ✅ Use textbook and online algorithm resources
- ✅ Get help debugging from TAs
- ❌ Copy code from classmates or online
- ❌ Share complete solutions with others
- ❌ Submit work that is not substantially your own

---

**Focus on understanding the concepts! These algorithms are fundamental to AI and computer science. Mastering them will set you up for success in more advanced topics. Good luck!**