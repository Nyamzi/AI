#!/usr/bin/env python3
"""
Project Setup Verification Script

Run this script to verify that your project structure is correct
and all files are properly set up.
"""

import os
import sys
import importlib.util

def check_file_exists(filepath, description):
    """Check if a file exists and report status"""
    if os.path.exists(filepath):
        print(f"✓ {description}: {filepath}")
        return True
    else:
        print(f"✗ MISSING {description}: {filepath}")
        return False

def check_directory_exists(dirpath, description):
    """Check if a directory exists and report status"""
    if os.path.isdir(dirpath):
        print(f"✓ {description}: {dirpath}")
        return True
    else:
        print(f"✗ MISSING {description}: {dirpath}")
        return False

def check_imports():
    """Check if all source files can be imported"""
    print("\n" + "="*50)
    print("TESTING IMPORTS")
    print("="*50)
    
    success = True
    
    # Add src to path
    src_path = os.path.join(os.path.dirname(__file__), 'src')
    sys.path.insert(0, src_path)
    
    modules_to_test = [
        ('bfs_grid', 'GridSearchBFS'),
        ('dfs_tree', 'TreeNode'),
        ('dfs_tree', 'TreeSearchDFS'), 
        ('ucs_graph', 'WeightedGraphUCS')
    ]
    
    for module_name, class_name in modules_to_test:
        try:
            module = importlib.import_module(module_name)
            cls = getattr(module, class_name)
            print(f"✓ Successfully imported {class_name} from {module_name}")
        except ImportError as e:
            print(f"✗ Failed to import {module_name}: {e}")
            success = False
        except AttributeError as e:
            print(f"✗ Class {class_name} not found in {module_name}: {e}")
            success = False
    
    return success

def main():
    """Main verification function"""
    print("Project 0 Setup Verification")
    print("="*50)
    
    # Check project structure
    files_to_check = [
        ("README.md", "Main README"),
        (".gitignore", "Git ignore file"),
        ("requirements.txt", "Python requirements"),
        ("docs/INSTRUCTIONS.md", "Assignment instructions"),
        ("docs/GRADING_RUBRIC.md", "Grading rubric"),
        ("src/bfs_grid.py", "BFS implementation"),
        ("src/dfs_tree.py", "DFS implementation"),
        ("src/ucs_graph.py", "UCS implementation"),
        ("tests/test_bfs.py", "BFS tests"),
        ("tests/test_dfs.py", "DFS tests"), 
        ("tests/test_ucs.py", "UCS tests"),
        ("tests/test_all.py", "All tests runner"),
        ("analysis/algorithm_comparison.py", "Algorithm comparison"),
        ("analysis/search_analysis.md", "Analysis report template"),
        ("problems/sample_problems.py", "Sample problems"),
    ]
    
    directories_to_check = [
        ("src", "Source code directory"),
        ("tests", "Test files directory"),
        ("docs", "Documentation directory"),
        ("analysis", "Analysis directory"),
        ("problems", "Problems directory"),
    ]
    
    print("\nCHECKING DIRECTORIES:")
    print("-" * 30)
    dir_success = all(check_directory_exists(d, desc) for d, desc in directories_to_check)
    
    print("\nCHECKING FILES:")
    print("-" * 30)
    file_success = all(check_file_exists(f, desc) for f, desc in files_to_check)
    
    # Check imports
    import_success = check_imports()
    
    # Final report
    print("\n" + "="*50)
    print("VERIFICATION SUMMARY")
    print("="*50)
    
    if dir_success and file_success and import_success:
        print("🎉 ALL CHECKS PASSED!")
        print("Your project structure is correctly set up.")
        print("\nNext steps:")
        print("1. Implement the TODO sections in src/ files")
        print("2. Run tests with: python tests/test_all.py")
        print("3. Complete algorithm comparison and analysis")
        return True
    else:
        print("❌ SOME CHECKS FAILED!")
        print("Please fix the issues above before proceeding.")
        if not dir_success:
            print("- Missing directories")
        if not file_success:
            print("- Missing files")
        if not import_success:
            print("- Import errors")
        return False

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)