"""
Test cases for BFS Grid Navigation implementation
"""

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'src'))

from bfs_grid import GridSearchBFS

def test_simple_path():
    """Test BFS on simple 3x3 grid with direct path"""
    grid = [
        [0, 0, 0],
        [0, 1, 0],
        [0, 0, 0]
    ]
    start = (0, 0)
    goal = (2, 2)
    
    search = GridSearchBFS(grid, start, goal)
    path, nodes_explored, max_frontier = search.breadth_first_search()
    
    print(f"Simple path test:")
    print(f"Path found: {path}")
    print(f"Nodes explored: {nodes_explored}")
    print(f"Max frontier size: {max_frontier}")
    
    if path:
        search.print_grid_with_path(path)
    print("-" * 50)

def test_no_path():
    """Test BFS when no path exists"""
    grid = [
        [0, 1, 0],
        [1, 1, 1],
        [0, 1, 0]
    ]
    start = (0, 0)
    goal = (2, 2)
    
    search = GridSearchBFS(grid, start, goal)
    path, nodes_explored, max_frontier = search.breadth_first_search()
    
    print(f"No path test:")
    print(f"Path found: {path}")
    print(f"Nodes explored: {nodes_explored}")
    print("-" * 50)

def test_complex_maze():
    """Test BFS on larger maze"""
    grid = [
        [0, 0, 1, 0, 0],
        [0, 1, 1, 0, 1],
        [0, 0, 0, 0, 0],
        [1, 1, 0, 1, 0],
        [0, 0, 0, 1, 0]
    ]
    start = (0, 0)
    goal = (4, 4)
    
    search = GridSearchBFS(grid, start, goal)
    path, nodes_explored, max_frontier = search.breadth_first_search()
    
    print(f"Complex maze test:")
    print(f"Path found: {path}")
    print(f"Path length: {len(path) if path else 0}")
    print(f"Nodes explored: {nodes_explored}")
    print(f"Max frontier size: {max_frontier}")
    
    if path:
        search.print_grid_with_path(path)
    print("-" * 50)

if __name__ == "__main__":
    print("Testing BFS Grid Navigation")
    print("=" * 50)
    
    test_simple_path()
    test_no_path()
    test_complex_maze()
    
    print("BFS tests completed!")