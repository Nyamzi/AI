"""
Test cases for UCS Weighted Graph Search implementation
"""

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'src'))

from ucs_graph import WeightedGraphUCS

def create_sample_graph():
    """Create a sample weighted graph for testing"""
    # Graph structure:
    #     A -2-> B -1-> D
    #     |      |      |
    #     3      4      2
    #     |      |      |
    #     v      v      v
    #     C -1-> E -3-> F
    
    graph = {
        'A': [('B', 2), ('C', 3)],
        'B': [('D', 1), ('E', 4)],
        'C': [('E', 1)],
        'D': [('F', 2)],
        'E': [('F', 3)],
        'F': []
    }
    return graph

def test_simple_path():
    """Test UCS on simple path"""
    graph = create_sample_graph()
    search = WeightedGraphUCS(graph)
    
    print("Graph structure:")
    search.print_graph()
    print()
    
    path, cost, nodes_explored, max_frontier = search.uniform_cost_search('A', 'F')
    
    print(f"Simple path test (A to F):")
    print(f"Path found: {path}")
    print(f"Total cost: {cost}")
    print(f"Nodes explored: {nodes_explored}")
    print(f"Max frontier size: {max_frontier}")
    print("-" * 50)

def test_optimal_vs_shortest():
    """Test that UCS finds optimal cost path, not necessarily shortest"""
    # In our graph, A->B->D->F (cost 5) vs A->C->E->F (cost 7)
    # UCS should find the first path
    graph = create_sample_graph()
    search = WeightedGraphUCS(graph)
    
    path, cost, nodes_explored, max_frontier = search.uniform_cost_search('A', 'F')
    
    print(f"Optimal vs shortest test (A to F):")
    print(f"Path found: {path}")
    print(f"Total cost: {cost}")
    print(f"Expected optimal cost: 5 (A->B->D->F)")
    print(f"Nodes explored: {nodes_explored}")
    print(f"Max frontier size: {max_frontier}")
    print("-" * 50)

def test_no_path():
    """Test UCS when no path exists"""
    graph = {
        'A': [('B', 1)],
        'B': [],
        'C': [('D', 2)],
        'D': []
    }
    search = WeightedGraphUCS(graph)
    
    path, cost, nodes_explored, max_frontier = search.uniform_cost_search('A', 'D')
    
    print(f"No path test (A to D):")
    print(f"Path found: {path}")
    print(f"Total cost: {cost}")
    print(f"Nodes explored: {nodes_explored}")
    print(f"Max frontier size: {max_frontier}")
    print("-" * 50)

def test_single_node():
    """Test UCS when start equals goal"""
    graph = create_sample_graph()
    search = WeightedGraphUCS(graph)
    
    path, cost, nodes_explored, max_frontier = search.uniform_cost_search('A', 'A')
    
    print(f"Single node test (A to A):")
    print(f"Path found: {path}")
    print(f"Total cost: {cost}")
    print(f"Nodes explored: {nodes_explored}")
    print(f"Max frontier size: {max_frontier}")
    print("-" * 50)

def test_complex_graph():
    """Test UCS on more complex graph with multiple paths"""
    graph = {
        'S': [('A', 1), ('B', 4)],
        'A': [('B', 2), ('C', 5), ('D', 12)],
        'B': [('C', 2)],
        'C': [('D', 3)],
        'D': [],
    }
    search = WeightedGraphUCS(graph)
    
    print("Complex graph structure:")
    search.print_graph()
    print()
    
    path, cost, nodes_explored, max_frontier = search.uniform_cost_search('S', 'D')
    
    print(f"Complex graph test (S to D):")
    print(f"Path found: {path}")
    print(f"Total cost: {cost}")
    print(f"Expected optimal: S->A->B->C->D (cost 8)")
    print(f"Nodes explored: {nodes_explored}")
    print(f"Max frontier size: {max_frontier}")
    print("-" * 50)

if __name__ == "__main__":
    print("Testing UCS Weighted Graph Search")
    print("=" * 50)
    
    test_simple_path()
    test_optimal_vs_shortest()
    test_no_path()
    test_single_node()
    test_complex_graph()
    
    print("UCS tests completed!")