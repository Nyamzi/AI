"""
Run all algorithm tests
"""

import subprocess
import sys
import os

def run_test_file(test_file):
    """Run a test file and capture output"""
    print(f"\n{'='*60}")
    print(f"RUNNING: {test_file}")
    print('='*60)
    
    try:
        result = subprocess.run([sys.executable, test_file], 
                              capture_output=True, text=True, cwd=os.path.dirname(__file__))
        
        if result.stdout:
            print(result.stdout)
        
        if result.stderr:
            print("ERRORS:")
            print(result.stderr)
            
        if result.returncode != 0:
            print(f"Test {test_file} failed with return code {result.returncode}")
            return False
        else:
            print(f"Test {test_file} completed successfully!")
            return True
            
    except Exception as e:
        print(f"Error running {test_file}: {e}")
        return False

def main():
    """Run all tests"""
    test_files = [
        'test_bfs.py',
        'test_dfs.py',
        'test_ucs.py'
    ]
    
    print("Running all algorithm tests...")
    
    results = []
    for test_file in test_files:
        success = run_test_file(test_file)
        results.append((test_file, success))
    
    print(f"\n{'='*60}")
    print("TEST SUMMARY")
    print('='*60)
    
    for test_file, success in results:
        status = "PASS" if success else "FAIL"
        print(f"{test_file}: {status}")
    
    all_passed = all(success for _, success in results)
    if all_passed:
        print("\nAll tests completed successfully! ✓")
    else:
        print("\nSome tests failed. ✗")
        print("Check the output above for details.")

if __name__ == "__main__":
    main()