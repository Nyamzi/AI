"""
Test cases for A* Grid Search implementation

Run with: python tests/test_astar.py
"""

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'src'))
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'problems'))

from astar_grid import GridSearchAStar
from sample_problems import get_simple_grid, get_maze_grid, get_no_solution_grid

def test_simple_grid():
    """Test A* on simple 3x3 grid"""
    print("=== Test 1: Simple Grid ===")
    grid, start, goal = get_simple_grid()
    
    astar = GridSearchAStar(grid, start, goal)
    path, nodes_explored, max_frontier = astar.astar_search()
    
    print(f"Start: {start}, Goal: {goal}")
    if path:
        print(f"✓ Path found with length: {len(path)}")
        print(f"✓ Path cost: {len(path) - 1}")
        print(f"✓ Nodes explored: {nodes_explored}")
        astar.print_grid_with_path(path)
        
        # Verify path validity
        assert path[0] == start, "Path should start at start position"
        assert path[-1] == goal, "Path should end at goal position"
        
        # Check path continuity
        for i in range(len(path) - 1):
            current = path[i]
            next_pos = path[i + 1]
            distance = abs(current[0] - next_pos[0]) + abs(current[1] - next_pos[1])
            assert distance == 1, f"Invalid step from {current} to {next_pos}"
        
        print("✓ Path validation passed")
    else:
        print("✗ No path found")
        return False
    
    print()
    return True

def test_maze_grid():
    """Test A* on 5x5 maze"""
    print("=== Test 2: Maze Grid ===")
    grid, start, goal = get_maze_grid()
    
    astar = GridSearchAStar(grid, start, goal)
    path, nodes_explored, max_frontier = astar.astar_search()
    
    print(f"Start: {start}, Goal: {goal}")
    if path:
        print(f"✓ Path found with length: {len(path)}")
        print(f"✓ Path cost: {len(path) - 1}")
        print(f"✓ Nodes explored: {nodes_explored}")
        astar.print_grid_with_path(path)
        
        # Verify optimality (for this specific maze, optimal path length is 9)
        optimal_length = 9
        if len(path) == optimal_length:
            print("✓ Optimal path found")
        else:
            print(f"⚠ Path length {len(path)} may not be optimal (expected ~{optimal_length})")
        
        print("✓ Path validation passed")
    else:
        print("✗ No path found")
        return False
    
    print()
    return True

def test_no_solution():
    """Test A* on grid with no solution"""
    print("=== Test 3: No Solution Grid ===")
    grid, start, goal = get_no_solution_grid()
    
    astar = GridSearchAStar(grid, start, goal)
    path, nodes_explored, max_frontier = astar.astar_search()
    
    print(f"Start: {start}, Goal: {goal}")
    if path is None:
        print("✓ Correctly identified no solution")
        print(f"✓ Nodes explored: {nodes_explored}")
    else:
        print(f"✗ Found path when none should exist: {path}")
        return False
    
    print()
    return True

def test_heuristics_comparison():
    """Compare different heuristics"""
    print("=== Test 4: Heuristics Comparison ===")
    grid, start, goal = get_maze_grid()
    
    heuristics = ['manhattan', 'euclidean', 'diagonal']
    results = {}
    
    for h in heuristics:
        astar = GridSearchAStar(grid, start, goal, h)
        path, nodes_explored, max_frontier = astar.astar_search()
        
        results[h] = {
            'path_length': len(path) if path else None,
            'nodes_explored': nodes_explored,
            'max_frontier': max_frontier
        }
        
        print(f"{h.capitalize()} heuristic:")
        print(f"  Path length: {results[h]['path_length']}")
        print(f"  Nodes explored: {results[h]['nodes_explored']}")
        print(f"  Max frontier size: {results[h]['max_frontier']}")
    
    # Manhattan should be most efficient for 4-connected grid
    manhattan_nodes = results['manhattan']['nodes_explored']
    euclidean_nodes = results['euclidean']['nodes_explored']
    
    if manhattan_nodes <= euclidean_nodes:
        print("✓ Manhattan heuristic is efficient (as expected)")
    else:
        print("⚠ Manhattan heuristic explored more nodes than Euclidean")
    
    print()
    return True

def test_invalid_positions():
    """Test A* with invalid start/goal positions"""
    print("=== Test 5: Invalid Positions ===")
    grid, _, _ = get_simple_grid()
    
    # Test invalid start
    astar = GridSearchAStar(grid, (-1, 0), (2, 2))
    path, _, _ = astar.astar_search()
    assert path is None, "Should return None for invalid start"
    print("✓ Invalid start position handled correctly")
    
    # Test invalid goal
    astar = GridSearchAStar(grid, (0, 0), (5, 5))
    path, _, _ = astar.astar_search()
    assert path is None, "Should return None for invalid goal"
    print("✓ Invalid goal position handled correctly")
    
    # Test start on obstacle
    astar = GridSearchAStar(grid, (1, 1), (2, 2))  # (1,1) is obstacle
    path, _, _ = astar.astar_search()
    assert path is None, "Should return None for start on obstacle"
    print("✓ Start on obstacle handled correctly")
    
    print()
    return True

def compare_with_bfs():
    """Compare A* performance with BFS"""
    print("=== Test 6: A* vs BFS Comparison ===")
    
    # Import BFS for comparison
    try:
        from bfs_grid import GridSearchBFS
        
        grid, start, goal = get_maze_grid()
        
        # Run BFS
        bfs = GridSearchBFS(grid, start, goal)
        bfs_path, bfs_nodes, bfs_frontier = bfs.breadth_first_search()
        
        # Run A*
        astar = GridSearchAStar(grid, start, goal)
        astar_path, astar_nodes, astar_frontier = astar.astar_search()
        
        print("BFS Results:")
        print(f"  Path length: {len(bfs_path) if bfs_path else None}")
        print(f"  Nodes explored: {bfs_nodes}")
        print(f"  Max frontier size: {bfs_frontier}")
        
        print("A* Results:")
        print(f"  Path length: {len(astar_path) if astar_path else None}")
        print(f"  Nodes explored: {astar_nodes}")
        print(f"  Max frontier size: {astar_frontier}")
        
        if astar_path and bfs_path:
            # Both should find optimal path
            assert len(astar_path) == len(bfs_path), "A* should find optimal path like BFS"
            print("✓ A* found optimal path")
            
            # A* should explore fewer nodes
            if astar_nodes <= bfs_nodes:
                print(f"✓ A* explored {bfs_nodes - astar_nodes} fewer nodes than BFS")
            else:
                print("⚠ A* explored more nodes than BFS (unusual)")
        
    except ImportError:
        print("BFS implementation not available for comparison")
    
    print()
    return True

def run_all_tests():
    """Run all A* tests"""
    print("=" * 50)
    print("Running A* Search Tests")
    print("=" * 50)
    
    tests = [
        test_simple_grid,
        test_maze_grid,
        test_no_solution,
        test_heuristics_comparison,
        test_invalid_positions,
        compare_with_bfs
    ]
    
    passed = 0
    total = len(tests)
    
    for test in tests:
        try:
            if test():
                passed += 1
        except Exception as e:
            print(f"✗ Test failed with error: {e}")
            import traceback
            traceback.print_exc()
    
    print("=" * 50)
    print(f"Test Results: {passed}/{total} tests passed")
    
    if passed == total:
        print("🎉 All A* tests passed!")
        return True
    else:
        print("❌ Some tests failed")
        return False

if __name__ == "__main__":
    run_all_tests()