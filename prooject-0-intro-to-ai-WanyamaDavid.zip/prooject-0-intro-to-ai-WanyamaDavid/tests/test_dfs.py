"""
Test cases for DFS Tree Traversal implementation
"""

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'src'))

from dfs_tree import TreeNode, TreeSearchDFS

def create_sample_tree():
    """Create a sample tree for testing"""
    #       A
    #      / \
    #     B   C
    #    /   / \
    #   D   E   F
    #      /
    #     G
    
    root = TreeNode('A')
    b = TreeNode('B')
    c = TreeNode('C')
    d = TreeNode('D')
    e = TreeNode('E')
    f = TreeNode('F')
    g = TreeNode('G')
    
    root.add_child(b)
    root.add_child(c)
    b.add_child(d)
    c.add_child(e)
    c.add_child(f)
    e.add_child(g)
    
    return root

def test_find_root():
    """Test DFS finding root node"""
    root = create_sample_tree()
    search = TreeSearchDFS(root, 'A')
    
    path, nodes_explored, max_depth = search.depth_first_search()
    
    print(f"Find root test:")
    print(f"Target: A")
    print(f"Path found: {path}")
    print(f"Nodes explored: {nodes_explored}")
    print(f"Max depth reached: {max_depth}")
    print("-" * 50)

def test_find_leaf():
    """Test DFS finding leaf node"""
    root = create_sample_tree()
    search = TreeSearchDFS(root, 'G')
    
    print("Tree structure:")
    search.print_tree()
    print()
    
    path, nodes_explored, max_depth = search.depth_first_search()
    
    print(f"Find leaf test:")
    print(f"Target: G")
    print(f"Path found: {path}")
    print(f"Nodes explored: {nodes_explored}")
    print(f"Max depth reached: {max_depth}")
    print("-" * 50)

def test_find_nonexistent():
    """Test DFS when target doesn't exist"""
    root = create_sample_tree()
    search = TreeSearchDFS(root, 'Z')
    
    path, nodes_explored, max_depth = search.depth_first_search()
    
    print(f"Find nonexistent test:")
    print(f"Target: Z")
    print(f"Path found: {path}")
    print(f"Nodes explored: {nodes_explored}")
    print(f"Max depth reached: {max_depth}")
    print("-" * 50)

def test_find_middle():
    """Test DFS finding middle node"""
    root = create_sample_tree()
    search = TreeSearchDFS(root, 'E')
    
    path, nodes_explored, max_depth = search.depth_first_search()
    
    print(f"Find middle node test:")
    print(f"Target: E")
    print(f"Path found: {path}")
    print(f"Nodes explored: {nodes_explored}")
    print(f"Max depth reached: {max_depth}")
    print("-" * 50)

if __name__ == "__main__":
    print("Testing DFS Tree Traversal")
    print("=" * 50)
    
    test_find_root()
    test_find_leaf()
    test_find_nonexistent()
    test_find_middle()
    
    print("DFS tests completed!")